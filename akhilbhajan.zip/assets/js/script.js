
// Marathi Number js
// function toMarathiNumber(num) {
//     const marathi = ['०', '१', '२', '३', '४', '५', '६', '७', '८', '९'];
//     return num.replace(/\d/g, d => marathi[d]);
// }

// document.getElementsByTagName("body").innerHTML =
//     toMarathiNumber(document.getElementsByTagName("body").innerHTML);

// Slider js
